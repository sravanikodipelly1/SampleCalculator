//
//  ViewController.swift
//  SampleCalculator
//
//  Created by Kodipelly,Sravani on 1/27/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displaylabel: UILabel!
    
    var operand1:Double = -1.1;
    var operand2:Double = -1.1;
    var CalcOperator:Character = " "
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func button1(_ sender: Any) {
        displaylabel.text = displaylabel.text! + "1"
        if(operand1 == -1.1){
            operand1 = 1
        }
        else{
            operand2 = 1
        }
    }
    @IBAction func button2(_ sender: Any) {
        displaylabel.text = displaylabel.text! + "2"
        if (operand2 == -1.1 && operand1 == -1.1){
            operand1 = 2
        }
        else{
            operand2 = 2
        }
    }
    
    
    @IBAction func button3(_ sender: Any) {
        displaylabel.text = displaylabel.text! + "+"
        if CalcOperator == " "{
            CalcOperator = "+"
        }
    }
    
    
    @IBAction func button4(_ sender: Any) {
        displaylabel.text = displaylabel.text! + "="
        if CalcOperator == "+"{
            displaylabel.text = displaylabel.text! + "\(operand1+operand2)"
        }
        else if CalcOperator == "-"{
            displaylabel.text = displaylabel.text! + "\(operand1-operand2)"
        }
        else {
            displaylabel.text = displaylabel.text! + "\(operand1*operand2)"
        }
    }
    
    @IBAction func button5(_ sender: Any) {
        displaylabel.text = displaylabel.text! + "-"
        if CalcOperator == " "{
            CalcOperator = "-"
        }
    }
    
    @IBAction func button6(_ sender: Any) {
        displaylabel.text = displaylabel.text! + "*"
        if CalcOperator == " "{
            CalcOperator = "*"
        }
    }
}

